package com.baining.str.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Environment
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat
import com.baining.str.manager.AppLogger
import com.baining.str.manager.RecordingStateHolder
import com.baining.str.manager.RootCaptureManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File

class FloatingWindowService : Service() {

    companion object {
        private const val TAG = "FloatingWindowService"
        private const val CHANNEL_ID = "floating_channel"
        private const val NOTIF_ID = 1002
        const val ACTION_SHOW = "action.FLOAT_SHOW"
        const val ACTION_HIDE = "action.FLOAT_HIDE"
        val isFloatingVisible = MutableStateFlow(false)

        //尺寸档位
        private const val SIZE_SMALL = 40
        private const val SIZE_NORMAL = 52}

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var wm: WindowManager? = null
    private var floatView: View? = null
    private var btnRecord: ImageButton? = null
    private var currentBtnSize = SIZE_NORMAL  // 当前按钮尺寸
    private var isSmall = false               // 是否折叠为小尺寸

    private val outputDir: File
        get() {
            val prefs = getSharedPreferences("bn_prefs", Context.MODE_PRIVATE)
            val defaultDir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "ScreenCapturePro"
            )
            return File(prefs.getString("save_dir", defaultDir.absolutePath) ?: defaultDir.absolutePath)
                .also { it.mkdirs() }
        }

    private val configuredFps: Int
        get() = getSharedPreferences("bn_prefs", Context.MODE_PRIVATE)
            .getInt("fps", 30).coerceIn(24, 120)

    private val configuredBitrateMbps: Int
        get() = getSharedPreferences("bn_prefs", Context.MODE_PRIVATE)
            .getInt("bitrate_mbps", 8).coerceIn(1, 40)

    private val configuredAudio: RootCaptureManager.AudioSource
        get() = RootCaptureManager.AudioSource.values().getOrElse(
            getSharedPreferences("bn_prefs", Context.MODE_PRIVATE).getInt("audio_source", 0)
        ) { RootCaptureManager.AudioSource.NONE }

    override fun onCreate() {
        super.onCreate()
        createNotifChannel()
        startForeground(NOTIF_ID, buildNotif())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        // Bug6：监听全局录屏状态变化
        scope.launch {
            RecordingStateHolder.isRecording.collect { recording ->
                btnRecord?.let { updateRecordBtn(it, recording) }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showFloat()
            ACTION_HIDE -> hideFloat()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        hideFloat()
        scope.cancel()
        super.onDestroy()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloat() {
        if (floatView != null) return

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 220}

        // Bug2修复：自定义 LinearLayout，onInterceptTouchEvent 区分拖动/点击
        var startRawX = 0f; var startRawY = 0f
        var startX = 0; var startY = 0
        var isDragging = false
        val dragSlop = 8f

        val container = object : LinearLayout(this) {
            override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
                return when (ev.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startRawX = ev.rawX; startRawY = ev.rawY
                        startX = params.x; startY = params.y
                        isDragging = false
                        false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val moved = Math.abs(ev.rawX - startRawX) > dragSlop ||Math.abs(ev.rawY - startRawY) > dragSlop
                        if (moved) isDragging = true
                        moved
                    }
                    else -> false
                }
            }

            @SuppressLint("ClickableViewAccessibility")
            override fun onTouchEvent(ev: MotionEvent): Boolean {
                return when (ev.action) {
                    MotionEvent.ACTION_MOVE -> {
                        if (isDragging) {
                            params.x = (startX - (ev.rawX - startRawX)).toInt()
                            params.y = (startY + (ev.rawY - startRawY)).toInt()
                            wm?.updateViewLayout(this, params)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        isDragging = false
                        true
                    }
                    else -> false
                }
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(14, 16, 14, 16)
                        background = buildContainerBg()
            isLongClickable = false
            //弹出动画：从按钮位置缩放放大
            scaleX = 0f; scaleY = 0f; alpha = 0f
        }

        // 截图按钮
        val btnShot = makeIconButton(Color.argb(210, 0, 122, 255), android.R.drawable.ic_menu_camera) {
            scope.launch(Dispatchers.IO) { RootCaptureManager.captureScreen(outputDir) }
        }

        // 录屏按钮（Bug6：初始状态从全局状态读取）
        val isRecNow = RecordingStateHolder.isRecording.value
        val recBtn = makeIconButton(
            if (isRecNow) Color.argb(220, 255, 59, 48) else Color.argb(210, 52, 199, 89),
            if (isRecNow) android.R.drawable.ic_media_pause else android.R.drawable.presence_video_online
        ) {
            scope.launch(Dispatchers.IO) {
if (RootCaptureManager.isRecording) {
                        val file = RootCaptureManager.stopRecording()
                        RecordingStateHolder.setRecording(false)
                        if (file != null) AppLogger.log(AppLogger.Category.RECORDING, "悬浮窗录屏完成", "文件=${file.absolutePath}; 大小=${file.length()} bytes")
                        else AppLogger.log(AppLogger.Category.ERROR, "悬浮窗录屏完成失败", "未生成有效 MP4")
                    } else {
                        when (val result = RootCaptureManager.startRecording(outputDir, configuredBitrateMbps, configuredFps, configuredAudio)) {
                            is RootCaptureManager.RecordResult.Started -> {
                                RecordingStateHolder.setRecording(true)
                                AppLogger.log(AppLogger.Category.RECORDING, "悬浮窗录屏开始", "文件=${result.file.absolutePath}; fps=$configuredFps; 码率=${configuredBitrateMbps}Mbps; 音频=$configuredAudio")
                            }
                            is RootCaptureManager.RecordResult.Error -> {
                                RecordingStateHolder.setRecording(false)
                                AppLogger.log(AppLogger.Category.ERROR, "悬浮窗录屏启动失败", result.message)
                            }
                            is RootCaptureManager.RecordResult.AlreadyRunning -> RecordingStateHolder.setRecording(true)
                        }
                }
            }
        }
        btnRecord = recBtn

        // 大小调节按钮（新增）
        val btnSize = makeIconButton(
            Color.argb(140, 80, 80, 90),
            android.R.drawable.ic_menu_zoom
        ) {
            toggleSize(container, params)
        }

        // 关闭按钮
        val btnClose = makeIconButton(Color.argb(160, 120, 120, 130),
            android.R.drawable.ic_menu_close_clear_cancel) { hideFloat() }

        val lp = LinearLayout.LayoutParams(SIZE_NORMAL.dpPx, SIZE_NORMAL.dpPx).apply {
            setMargins(0, 6, 0, 6)}
        container.addView(btnShot, lp)
        container.addView(recBtn, lp)
        container.addView(btnSize, lp)
        container.addView(btnClose, lp)

        floatView = container
        try {
            wm?.addView(container, params)
            isFloatingVisible.value = true
            //弹出动画
            container.animate()
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(280)
                .setInterpolator(OvershootInterpolator(1.2f))
                .start()
            Log.i(TAG, "Floating window shown")
        } catch (e: Exception) {
            Log.e(TAG, "addView failed: ${e.message}")
            floatView = null
        }
    }

    /** 大小切换动画 */
    private fun toggleSize(container: LinearLayout, params: WindowManager.LayoutParams) {
        isSmall = !isSmall
        val targetSize = if (isSmall) SIZE_SMALL else SIZE_NORMAL
        val targetPadding = if (isSmall) 8 else 14

        container.animate()
            .scaleX(0.8f).scaleY(0.8f)
            .setDuration(120)
            .withEndAction {
                // 更新按钮尺寸
                for (i in 0 until container.childCount) {
                    val child = container.getChildAt(i)
                    val lp = child.layoutParams as LinearLayout.LayoutParams
                    lp.width = targetSize.dpPx
                    lp.height = targetSize.dpPx
                    child.layoutParams = lp
                }
                container.setPadding(targetPadding.dpPx, (targetPadding + 2).dpPx,
                    targetPadding.dpPx, (targetPadding + 2).dpPx)
                container.requestLayout()
                wm?.updateViewLayout(container, params)

                container.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(180)
                    .setInterpolator(OvershootInterpolator(1.5f))
                    .start()
            }.start()
    }

    private fun hideFloat() {
        floatView?.let {
            it.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(180)
                .withEndAction {
                    try { wm?.removeView(it) } catch (_: Exception) {}
                    floatView = null
                    btnRecord = null
                    isFloatingVisible.value = false
                }.start()
        }
    }

    private fun updateRecordBtn(btn: ImageButton, recording: Boolean) {
        btn.setImageResource(
            if (recording) android.R.drawable.ic_media_pause
            else android.R.drawable.presence_video_online
        )
        btn.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (recording) Color.argb(220, 255, 59, 48) else Color.argb(210, 52, 199, 89))
        }
    }

    private fun makeIconButton(bgColor: Int, iconRes: Int, onClick: () -> Unit): ImageButton {
        return ImageButton(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            // 图标铺满按钮区域，与截图按钮视觉一致
            scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            setPadding(14.dpPx, 14.dpPx, 14.dpPx, 14.dpPx)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(bgColor)
            }
            elevation = 6f
            isClickable = true
            isFocusable = false
            // 点击弹簧缩放动画
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.animate().scaleX(0.82f).scaleY(0.82f).setDuration(80).start()
                        false
                    }
                    MotionEvent.ACTION_UP -> {
                        v.animate().scaleX(1f).scaleY(1f)
                            .setDuration(160)
                            .setInterpolator(OvershootInterpolator(2.5f))
                            .withEndAction { onClick() }
                            .start()
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        false
                    }
                    else -> false
                }
            }
        }
    }

    private fun buildContainerBg() = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = 60f
        setColor(Color.argb(185, 255, 255, 255))
        setStroke(2, Color.argb(80, 255, 255, 255))
    }

    private val Int.dpPx: Int
        get() = (this * resources.displayMetrics.density).toInt()

    private fun createNotifChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "悬浮控制栏", NotificationManager.IMPORTANCE_MIN)
        ch.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotif(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("悬浮控制栏运行中")
            .setContentText("白柠强制过防录屏")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true).setSilent(true).build()
}
