package com.baining.str.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.baining.str.MainActivity
import com.baining.str.manager.AppLogger
import com.baining.str.manager.RecordingStateHolder
import com.baining.str.manager.RootCaptureManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

class ScreenCaptureService : Service() {

    companion object {
        private const val TAG = "ScreenCaptureService"
        private const val CHANNEL_ID = "screen_capture_channel"
        private const val NOTIF_ID = 1001

        const val ACTION_STOP_SERVICE = "action.STOP_SERVICE"
    }

    inner class LocalBinder : Binder() {
        fun getService() = this@ScreenCaptureService
    }

    private val binder = LocalBinder()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _status = MutableStateFlow<ServiceStatus>(ServiceStatus.Idle)
    val status: StateFlow<ServiceStatus> = _status

    override fun onCreate() {
        super.onCreate()
        AppLogger.initialize(this)
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("就绪 — 等待操作"))
        scope.launch {
            RootCaptureManager.automaticRecordingResult.collect { file ->
                RecordingStateHolder.setRecording(false)
                if (file != null) {
                    _status.value = ServiceStatus.RecordSuccess(file)
                    updateNotification("录屏已自动结束并保存: ${file.name}")
                } else {
                    _status.value = ServiceStatus.Error("长录屏自动结束，但没有生成有效视频")
                    updateNotification("录屏自动结束：无有效视频")
                }
            }
        }
        Log.i(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) stopSelf()
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onDestroy() {
        scope.cancel()
        scope.launch { RootCaptureManager.stopRecording() }
        super.onDestroy()
    }

    //──截图 ──────────────────────────────────────────────────

    fun doScreenshot(
        outputDir: File,
        mode: RootCaptureManager.CaptureMode = RootCaptureManager.CaptureMode.SOURCE
    ) {
        scope.launch {
            _status.value = ServiceStatus.Capturing
            updateNotification(if (mode == RootCaptureManager.CaptureMode.MODULE) "模块读取显示分区…" else "源码模式截图…")
            when (val result = RootCaptureManager.captureScreen(outputDir, mode, context = this@ScreenCaptureService)) {
                is RootCaptureManager.CaptureResult.Success -> {
                    // 部分 ROM 的 screencap 排除 overlay；仅在悬浮窗显示时合成自身控件副本。
                    if (FloatingWindowService.isFloatingVisible.value) {
                        RootCaptureManager.composeFloatingControls(
                            result.file,
                            RecordingStateHolder.isRecording.value
                        )
                    }
                    _status.value = ServiceStatus.CaptureSuccess(result.file)
                    updateNotification("截图已保存: ${result.file.name}")
                    vibrate(50L)
                    Log.i(TAG, "Screenshot: ${result.file.absolutePath}")
                    AppLogger.log(AppLogger.Category.SCREENSHOT, "截图成功", "模式=$mode; 文件=${result.file.absolutePath}; 大小=${result.file.length()} bytes")
                }
                is RootCaptureManager.CaptureResult.Error -> {
                    _status.value = ServiceStatus.Error(result.message)
                    updateNotification("截图失败")
                    Log.e(TAG, "Screenshot error: ${result.message}")
                    AppLogger.log(AppLogger.Category.ERROR, "截图失败", "模式=$mode; 目录=${outputDir.absolutePath}; 原因=${result.message}")
                }
            }
        }
    }

    // ── 录屏 ──────────────────────────────────────────────────

    fun doStartRecord(
        outputDir: File,
        bitrateMbps: Int = 8,
        fps: Int = 30,
        audio: RootCaptureManager.AudioSource = RootCaptureManager.AudioSource.NONE
    ) {
        scope.launch {
            // 立即给 UI 一个"正在启动"的反馈，避免卡顿感
            updateNotification("● 正在启动录屏…")
            when (val result = RootCaptureManager.startRecording(outputDir, bitrateMbps, fps, audio)) {
                is RootCaptureManager.RecordResult.Started -> {
                    // 确认进程已启动后才更新状态，保证同步准确
                    _status.value = ServiceStatus.Recording
                    RecordingStateHolder.setRecording(true)
                    val audioLabel = when (audio) {
                        RootCaptureManager.AudioSource.NONE     -> "静音"
                        RootCaptureManager.AudioSource.INTERNAL -> "内录"
                        RootCaptureManager.AudioSource.MIC      -> "麦克风"
                    }
                    updateNotification("● 录屏中 ${fps}fps · $audioLabel")
                    Log.i(TAG, "Recording started: ${result.file.absolutePath}")
                    AppLogger.log(AppLogger.Category.RECORDING, "录屏开始", "文件=${result.file.absolutePath}; fps=$fps; 码率=${bitrateMbps}Mbps; 音频=$audio")
                }
                is RootCaptureManager.RecordResult.AlreadyRunning -> {
                    _status.value = ServiceStatus.Recording
                    RecordingStateHolder.setRecording(true)
                    Log.w(TAG, "Already recording")
                }
                is RootCaptureManager.RecordResult.Error -> {
                    _status.value = ServiceStatus.Error(result.message)
                    RecordingStateHolder.setRecording(false)
                    updateNotification("录屏失败")
                    Log.e(TAG, "Record error: ${result.message}")
                    AppLogger.log(AppLogger.Category.ERROR, "录屏启动失败", "目录=${outputDir.absolutePath}; fps=$fps; 码率=${bitrateMbps}Mbps; 音频=$audio; 原因=${result.message}")
                }
            }
        }
    }

    fun doStopRecord() {
        scope.launch {
            updateNotification("正在停止录屏…")
            val file = RootCaptureManager.stopRecording()
            // Bug6：清除全局状态
            RecordingStateHolder.setRecording(false)
            if (file != null) {
                val analysis = RootCaptureManager.lastRecordingAnalysis
                if (analysis?.blackRanges?.isNotEmpty() == true) {
                    val ranges = analysis.blackRanges.joinToString()
                    _status.value = ServiceStatus.Error("视频已保存，但检测到连续黑屏：$ranges。捕获源可能使用受保护或独立合成图层。")
                    updateNotification("视频已保存，但检测到黑屏区间")
                } else {
                    _status.value = ServiceStatus.RecordSuccess(file)
                    updateNotification("录屏已保存: ${file.name}")
                }
                vibrate(100L)
                Log.i(TAG, "Record saved: ${file.absolutePath}")
                AppLogger.log(AppLogger.Category.RECORDING, "录屏完成", "文件=${file.absolutePath}; 大小=${file.length()} bytes; 黑屏区间=${analysis?.blackRanges?.joinToString().orEmpty()}")
            } else {
                _status.value = ServiceStatus.Error("录制结束但没有生成有效视频，请运行自我检测并查看错误日志")
                updateNotification("录屏失败：无有效视频")
                AppLogger.log(AppLogger.Category.ERROR, "录屏完成失败", "stopRecording 未返回有效 MP4（文件不存在或小于 4KB）")
            }
        }
    }

    val isRecording: Boolean get() = RootCaptureManager.isRecording

    // ── 通知 ──────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "屏幕捕获", NotificationManager.IMPORTANCE_LOW)
        ch.description = "屏幕截图与录制服务"
        ch.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, ScreenCaptureService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("白柠强制过防录屏")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "停止", stopPi)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    // ── 振动 ──────────────────────────────────────────────────

    private fun vibrate(ms: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(VibratorManager::class.java)?.defaultVibrator    ?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    .vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {}
    }

    // ── 状态密封类 ─────────────────────────────────────────────

    sealed class ServiceStatus {
        object Idle : ServiceStatus()
        object Capturing : ServiceStatus()
        object Recording : ServiceStatus()
        data class CaptureSuccess(val file: File) : ServiceStatus()
        data class RecordSuccess(val file: File) : ServiceStatus()
        data class Error(val message: String) : ServiceStatus()
    }
}
